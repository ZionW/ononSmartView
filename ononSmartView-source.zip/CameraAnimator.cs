using System.Diagnostics;
using Rhino.Display;
using Rhino.Geometry;
using Rhino.DocObjects;

namespace OnonSmartView;

internal static class CameraAnimator
{
    private const int DurationMilliseconds = 450;
    private static System.Threading.Timer? _timer;
    private static long _generation;

    public static long Animate(RhinoView view, ViewportInfo to, Action completed, ViewportInfo? fromProjection = null)
    {
        var generation = System.Threading.Interlocked.Increment(ref _generation);
        _timer?.Dispose();
        var viewport = view.ActiveViewport;
        var from = fromProjection ?? new ViewportInfo(viewport);
        var fromLocation = from.CameraLocation;
        var fromTarget = viewport.CameraTarget;
        var fromDirection = from.CameraDirection;
        var fromUp = from.CameraUp;
        var toLocation = to.CameraLocation;
        var toTarget = to.TargetPoint;
        var toDirection = to.CameraDirection;
        var toUp = to.CameraUp;
        var stopwatch = Stopwatch.StartNew();

        System.Threading.Timer? timer = null;
        timer = new System.Threading.Timer(_ =>
        {
            var t = Math.Clamp(stopwatch.Elapsed.TotalMilliseconds / DurationMilliseconds, 0, 1);
            var eased = t * t * (3 - 2 * t);
            Rhino.RhinoApp.InvokeOnUiThread((Action)(() =>
            {
                if (System.Threading.Volatile.Read(ref _generation) != generation) return;
                if (!view.ActiveViewport.IsValidCamera)
                {
                    timer?.Dispose();
                    _timer = null;
                    return;
                }

                var vp = view.ActiveViewport;
                var direction = Lerp(fromDirection, toDirection, eased);
                if (!direction.Unitize()) direction = toDirection;
                var up = Lerp(fromUp, toUp, eased);
                if (!up.Unitize()) up = toUp;
                vp.SetCameraLocations(Lerp(fromTarget, toTarget, eased), Lerp(fromLocation, toLocation, eased));
                vp.SetCameraDirection(direction, false);
                var frame = new ViewportInfo(vp);
                frame.SetCameraUp(up);
                vp.SetViewProjection(frame, false);
                vp.CameraUp = up;

                if (t >= 1)
                {
                    vp.SetViewProjection(to, false);
                    vp.SetCameraLocations(toTarget, toLocation);
                    vp.SetCameraDirection(toDirection, false);
                    var finalFrame = new ViewportInfo(to);
                    finalFrame.SetCameraUp(toUp);
                    vp.SetViewProjection(finalFrame, false);
                    if (to.IsPerspectiveProjection)
                        vp.Camera35mmLensLength = to.Camera35mmLensLength;
                    vp.SetCameraLocations(toTarget, toLocation);
                    vp.SetCameraDirection(toDirection, false);
                    vp.CameraUp = toUp;
                    timer?.Dispose();
                    _timer = null;
                    view.Redraw();
                    completed();
                }
                else
                {
                    view.Redraw();
                }
            }), null);
        }, null, 0, 15);
        _timer = timer;
        return generation;
    }

    public static void Cancel(long generation)
    {
        if (generation == 0 ||
            System.Threading.Interlocked.CompareExchange(ref _generation, generation + 1, generation) != generation)
            return;
        _timer?.Dispose();
        _timer = null;
    }

    public static ViewportInfo MakeFocusProjection(FocusSession session, bool flipped)
    {
        var plane = session.FocusPlane;
        var normal = plane.Normal;
        if (flipped) normal = -normal;
        var info = new ViewportInfo(session.OriginalProjection);
        info.ChangeToParallelProjection(true);
        info.TargetPoint = session.FocusTarget;
        info.SetCameraLocation(session.FocusTarget + normal * session.FocusDistance);
        info.SetCameraDirection(-normal);
        info.SetCameraUp(plane.YAxis);
        return info;
    }

    public static void AlignToPlane(RhinoViewport viewport, Plane plane,
        Point3d target, double distance, bool flipped = false)
    {
        if (!plane.IsValid) return;
        var normal = flipped ? -plane.Normal : plane.Normal;
        viewport.SetCameraLocations(target, target + normal * distance);
        viewport.SetCameraDirection(-normal, false);
        viewport.CameraUp = plane.YAxis;
    }

    private static Point3d Lerp(Point3d a, Point3d b, double t) => new(
        a.X + (b.X - a.X) * t, a.Y + (b.Y - a.Y) * t, a.Z + (b.Z - a.Z) * t);

    private static Vector3d Lerp(Vector3d a, Vector3d b, double t) => new(
        a.X + (b.X - a.X) * t, a.Y + (b.Y - a.Y) * t, a.Z + (b.Z - a.Z) * t);
}
