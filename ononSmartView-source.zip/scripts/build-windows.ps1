param(
    [string]$RhinoCommonPath = (Join-Path $env:ProgramFiles 'Rhino 8/System/RhinoCommon.dll'),
    [string]$OutputDirectory = (Join-Path $PSScriptRoot '../dist/Windows')
)

$ErrorActionPreference = 'Stop'
$project = Join-Path $PSScriptRoot '../ononSmartView.csproj'
$RhinoCommonPath = [System.IO.Path]::GetFullPath($RhinoCommonPath)
$OutputDirectory = [System.IO.Path]::GetFullPath($OutputDirectory)

if (-not (Test-Path -LiteralPath $RhinoCommonPath)) {
    throw "RhinoCommon.dll was not found at '$RhinoCommonPath'. Install Rhino 8 or pass -RhinoCommonPath."
}

dotnet build $project -c Release -p:UseRhinoRuntimeReferences=false "-p:RhinoCommonPath=$RhinoCommonPath"
if ($LASTEXITCODE -ne 0) {
    throw 'The ononSmartView build failed.'
}

$buildDirectory = Join-Path (Split-Path $project) 'bin/Release/net8.0'
$packageDirectory = Join-Path $OutputDirectory 'manual-load'
New-Item -ItemType Directory -Force -Path $packageDirectory | Out-Null
Copy-Item (Join-Path $buildDirectory 'ononSmartView.dll') (Join-Path $packageDirectory 'ononSmartView.rhp') -Force
Copy-Item (Join-Path $buildDirectory 'ononSmartView.deps.json') (Join-Path $packageDirectory 'ononSmartView.deps.json') -Force

$zipPath = Join-Path $OutputDirectory 'ononSmartView.zip'
$rhiPath = Join-Path $OutputDirectory 'ononSmartView.rhi'
Remove-Item $zipPath, $rhiPath -Force -ErrorAction SilentlyContinue
Compress-Archive -Path (Join-Path $packageDirectory '*') -DestinationPath $zipPath -Force
Move-Item $zipPath $rhiPath -Force
Write-Host "Windows package created: $rhiPath"
